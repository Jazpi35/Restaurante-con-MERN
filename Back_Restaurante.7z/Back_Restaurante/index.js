const Server = require('./data/server');
const server = new Server();
server.listen();
